# legacy_code
Some old legacy code that nobody cares about. Standard GPLv3.

`Badge/` - BadgeService implementation. Figure it out yourself.
