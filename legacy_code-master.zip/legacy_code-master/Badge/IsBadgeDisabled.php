<?php
	header("Content-Encoding: none");
	// 0 = enabled badge system
	// 1 = disabled badge system
	
	echo "0";
	die();
?>