﻿namespace SamSploitV2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.formSkin1 = new FlatUI.FormSkin();
            this.flatButton1 = new FlatUI.FlatButton();
            this.exit = new FlatUI.FlatButton();
            this.flatTabControl1 = new FlatUI.FlatTabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.flatLabel1 = new FlatUI.FlatLabel();
            this.flatLabel2 = new FlatUI.FlatLabel();
            this.flatLabel3 = new FlatUI.FlatLabel();
            this.flatLabel4 = new FlatUI.FlatLabel();
            this.cmdTXT = new FlatUI.FlatTextBox();
            this.flatButton2 = new FlatUI.FlatButton();
            this.lLUAbtn = new FlatUI.FlatButton();
            this.LUACbtn = new FlatUI.FlatButton();
            this.cmdLS = new System.Windows.Forms.RichTextBox();
            this.cmdListTXT = new System.Windows.Forms.RichTextBox();
            this.srcCodeTXT = new System.Windows.Forms.RichTextBox();
            this.formSkin1.SuspendLayout();
            this.flatTabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.SuspendLayout();
            // 
            // formSkin1
            // 
            this.formSkin1.BackColor = System.Drawing.Color.White;
            this.formSkin1.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.formSkin1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(58)))), ((int)(((byte)(60)))));
            this.formSkin1.Controls.Add(this.flatTabControl1);
            this.formSkin1.Controls.Add(this.exit);
            this.formSkin1.Controls.Add(this.flatButton1);
            this.formSkin1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.formSkin1.FlatColor = System.Drawing.Color.Green;
            this.formSkin1.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.formSkin1.HeaderColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.formSkin1.HeaderMaximize = false;
            this.formSkin1.Location = new System.Drawing.Point(0, 0);
            this.formSkin1.Name = "formSkin1";
            this.formSkin1.Size = new System.Drawing.Size(800, 450);
            this.formSkin1.TabIndex = 0;
            this.formSkin1.Text = "SamSploit v2";
            // 
            // flatButton1
            // 
            this.flatButton1.BackColor = System.Drawing.Color.Transparent;
            this.flatButton1.BaseColor = System.Drawing.Color.Green;
            this.flatButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.flatButton1.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.flatButton1.Location = new System.Drawing.Point(555, 3);
            this.flatButton1.Name = "flatButton1";
            this.flatButton1.Rounded = false;
            this.flatButton1.Size = new System.Drawing.Size(153, 44);
            this.flatButton1.TabIndex = 1;
            this.flatButton1.Text = "Inject";
            this.flatButton1.TextColor = System.Drawing.Color.White;
            this.flatButton1.UseCustomColor = false;
            this.flatButton1.Click += new System.EventHandler(this.flatButton1_Click);
            // 
            // exit
            // 
            this.exit.BackColor = System.Drawing.Color.Transparent;
            this.exit.BaseColor = System.Drawing.Color.Green;
            this.exit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.exit.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.exit.Location = new System.Drawing.Point(750, 3);
            this.exit.Name = "exit";
            this.exit.Rounded = false;
            this.exit.Size = new System.Drawing.Size(50, 37);
            this.exit.TabIndex = 2;
            this.exit.Text = "X";
            this.exit.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.exit.UseCustomColor = false;
            this.exit.Click += new System.EventHandler(this.exit_Click);
            // 
            // flatTabControl1
            // 
            this.flatTabControl1.ActiveColor = System.Drawing.Color.Green;
            this.flatTabControl1.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.flatTabControl1.Controls.Add(this.tabPage1);
            this.flatTabControl1.Controls.Add(this.tabPage2);
            this.flatTabControl1.Controls.Add(this.tabPage3);
            this.flatTabControl1.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.flatTabControl1.ItemSize = new System.Drawing.Size(120, 40);
            this.flatTabControl1.Location = new System.Drawing.Point(3, 49);
            this.flatTabControl1.Name = "flatTabControl1";
            this.flatTabControl1.SelectedIndex = 0;
            this.flatTabControl1.Size = new System.Drawing.Size(794, 398);
            this.flatTabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.flatTabControl1.TabIndex = 3;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.tabPage1.Controls.Add(this.cmdListTXT);
            this.tabPage1.Controls.Add(this.cmdLS);
            this.tabPage1.Controls.Add(this.flatButton2);
            this.tabPage1.Controls.Add(this.cmdTXT);
            this.tabPage1.Location = new System.Drawing.Point(4, 44);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(786, 350);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Commands";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.tabPage2.Controls.Add(this.srcCodeTXT);
            this.tabPage2.Controls.Add(this.LUACbtn);
            this.tabPage2.Controls.Add(this.lLUAbtn);
            this.tabPage2.Location = new System.Drawing.Point(4, 44);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(786, 350);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "LUA";
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.tabPage3.Controls.Add(this.flatLabel4);
            this.tabPage3.Controls.Add(this.flatLabel3);
            this.tabPage3.Controls.Add(this.flatLabel2);
            this.tabPage3.Controls.Add(this.flatLabel1);
            this.tabPage3.Location = new System.Drawing.Point(4, 44);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(786, 350);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "About";
            // 
            // flatLabel1
            // 
            this.flatLabel1.AutoSize = true;
            this.flatLabel1.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel1.Font = new System.Drawing.Font("Segoe UI", 26F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flatLabel1.ForeColor = System.Drawing.Color.White;
            this.flatLabel1.Location = new System.Drawing.Point(201, 105);
            this.flatLabel1.Name = "flatLabel1";
            this.flatLabel1.Size = new System.Drawing.Size(351, 70);
            this.flatLabel1.TabIndex = 0;
            this.flatLabel1.Text = "SamSploit v2";
            // 
            // flatLabel2
            // 
            this.flatLabel2.AutoSize = true;
            this.flatLabel2.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel2.Font = new System.Drawing.Font("Segoe UI", 11F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flatLabel2.ForeColor = System.Drawing.Color.White;
            this.flatLabel2.Location = new System.Drawing.Point(432, 175);
            this.flatLabel2.Name = "flatLabel2";
            this.flatLabel2.Size = new System.Drawing.Size(178, 30);
            this.flatLabel2.TabIndex = 1;
            this.flatLabel2.Text = "by Sparksammy";
            // 
            // flatLabel3
            // 
            this.flatLabel3.AutoSize = true;
            this.flatLabel3.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel3.Font = new System.Drawing.Font("Segoe UI", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flatLabel3.ForeColor = System.Drawing.Color.White;
            this.flatLabel3.Location = new System.Drawing.Point(18, 277);
            this.flatLabel3.Name = "flatLabel3";
            this.flatLabel3.Size = new System.Drawing.Size(693, 21);
            this.flatLabel3.TabIndex = 2;
            this.flatLabel3.Text = "WARNING: SPARKSAMMY.COM AND IT\'S AFFILIATES DO NOT CONDONE ILLEGAL ACTIONS,";
            // 
            // flatLabel4
            // 
            this.flatLabel4.AutoSize = true;
            this.flatLabel4.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel4.Font = new System.Drawing.Font("Segoe UI", 11F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flatLabel4.ForeColor = System.Drawing.Color.White;
            this.flatLabel4.Location = new System.Drawing.Point(329, 298);
            this.flatLabel4.Name = "flatLabel4";
            this.flatLabel4.Size = new System.Drawing.Size(452, 30);
            this.flatLabel4.TabIndex = 3;
            this.flatLabel4.Text = "USE FOR EDUCATIONAL PURPOSES ONLY!";
            // 
            // cmdTXT
            // 
            this.cmdTXT.BackColor = System.Drawing.Color.Transparent;
            this.cmdTXT.FocusOnHover = false;
            this.cmdTXT.Hint = "";
            this.cmdTXT.Location = new System.Drawing.Point(-7, 290);
            this.cmdTXT.MaxLength = 32767;
            this.cmdTXT.Multiline = false;
            this.cmdTXT.Name = "cmdTXT";
            this.cmdTXT.ReadOnly = false;
            this.cmdTXT.Size = new System.Drawing.Size(678, 38);
            this.cmdTXT.TabIndex = 1;
            this.cmdTXT.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.cmdTXT.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.cmdTXT.UseSystemPasswordChar = false;
            // 
            // flatButton2
            // 
            this.flatButton2.BackColor = System.Drawing.Color.Transparent;
            this.flatButton2.BaseColor = System.Drawing.Color.Green;
            this.flatButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.flatButton2.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.flatButton2.Location = new System.Drawing.Point(674, 290);
            this.flatButton2.Name = "flatButton2";
            this.flatButton2.Rounded = false;
            this.flatButton2.Size = new System.Drawing.Size(116, 41);
            this.flatButton2.TabIndex = 2;
            this.flatButton2.Text = "SEND";
            this.flatButton2.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.flatButton2.UseCustomColor = false;
            this.flatButton2.Click += new System.EventHandler(this.flatButton2_Click);
            // 
            // lLUAbtn
            // 
            this.lLUAbtn.BackColor = System.Drawing.Color.Transparent;
            this.lLUAbtn.BaseColor = System.Drawing.Color.Green;
            this.lLUAbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lLUAbtn.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.lLUAbtn.Location = new System.Drawing.Point(6, 300);
            this.lLUAbtn.Name = "lLUAbtn";
            this.lLUAbtn.Rounded = false;
            this.lLUAbtn.Size = new System.Drawing.Size(358, 44);
            this.lLUAbtn.TabIndex = 4;
            this.lLUAbtn.Text = "Limited LUA";
            this.lLUAbtn.TextColor = System.Drawing.Color.White;
            this.lLUAbtn.UseCustomColor = false;
            this.lLUAbtn.Click += new System.EventHandler(this.lLUAbtn_Click);
            // 
            // LUACbtn
            // 
            this.LUACbtn.BackColor = System.Drawing.Color.Transparent;
            this.LUACbtn.BaseColor = System.Drawing.Color.Green;
            this.LUACbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.LUACbtn.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.LUACbtn.Location = new System.Drawing.Point(422, 300);
            this.LUACbtn.Name = "LUACbtn";
            this.LUACbtn.Rounded = false;
            this.LUACbtn.Size = new System.Drawing.Size(358, 44);
            this.LUACbtn.TabIndex = 5;
            this.LUACbtn.Text = "LUAC";
            this.LUACbtn.TextColor = System.Drawing.Color.White;
            this.LUACbtn.UseCustomColor = false;
            this.LUACbtn.Click += new System.EventHandler(this.LUACbtn_Click);
            // 
            // cmdLS
            // 
            this.cmdLS.BackColor = System.Drawing.Color.Black;
            this.cmdLS.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.cmdLS.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.cmdLS.Location = new System.Drawing.Point(3, 3);
            this.cmdLS.Name = "cmdLS";
            this.cmdLS.ReadOnly = true;
            this.cmdLS.Size = new System.Drawing.Size(610, 278);
            this.cmdLS.TabIndex = 4;
            this.cmdLS.Text = "";
            // 
            // cmdListTXT
            // 
            this.cmdListTXT.BackColor = System.Drawing.Color.Black;
            this.cmdListTXT.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.cmdListTXT.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.cmdListTXT.Location = new System.Drawing.Point(629, 3);
            this.cmdListTXT.Name = "cmdListTXT";
            this.cmdListTXT.ReadOnly = true;
            this.cmdListTXT.Size = new System.Drawing.Size(161, 278);
            this.cmdListTXT.TabIndex = 5;
            this.cmdListTXT.Text = "";
            // 
            // srcCodeTXT
            // 
            this.srcCodeTXT.BackColor = System.Drawing.Color.Black;
            this.srcCodeTXT.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.srcCodeTXT.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.srcCodeTXT.Location = new System.Drawing.Point(0, 0);
            this.srcCodeTXT.Name = "srcCodeTXT";
            this.srcCodeTXT.Size = new System.Drawing.Size(786, 294);
            this.srcCodeTXT.TabIndex = 6;
            this.srcCodeTXT.Text = "";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.formSkin1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.TransparencyKey = System.Drawing.Color.Fuchsia;
            this.formSkin1.ResumeLayout(false);
            this.flatTabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private FlatUI.FormSkin formSkin1;
        private FlatUI.FlatButton exit;
        private FlatUI.FlatButton flatButton1;
        private FlatUI.FlatTabControl flatTabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private FlatUI.FlatLabel flatLabel4;
        private FlatUI.FlatLabel flatLabel3;
        private FlatUI.FlatLabel flatLabel2;
        private FlatUI.FlatLabel flatLabel1;
        private FlatUI.FlatButton flatButton2;
        private FlatUI.FlatTextBox cmdTXT;
        private FlatUI.FlatButton LUACbtn;
        private FlatUI.FlatButton lLUAbtn;
        private System.Windows.Forms.RichTextBox cmdListTXT;
        private System.Windows.Forms.RichTextBox cmdLS;
        private System.Windows.Forms.RichTextBox srcCodeTXT;
    }
}

