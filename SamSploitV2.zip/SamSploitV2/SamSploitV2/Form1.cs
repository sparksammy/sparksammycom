﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SamSploitV2
{
    public partial class Form1 : Form
    {
        [System.Runtime.InteropServices.DllImport("WeAreDevs_API.cpp.dll", CallingConvention = System.Runtime.InteropServices.CallingConvention.Cdecl)]
        public static extern bool LaunchExploit();

        [System.Runtime.InteropServices.DllImport("WeAreDevs_API.cpp.dll", CallingConvention = System.Runtime.InteropServices.CallingConvention.Cdecl)]
        public static extern bool SendLuaCScript(string script);

        [System.Runtime.InteropServices.DllImport("WeAreDevs_API.cpp.dll", CallingConvention = System.Runtime.InteropServices.CallingConvention.Cdecl)]
        public static extern bool SendLimitedLuaScript(string script);

        [System.Runtime.InteropServices.DllImport("WeAreDevs_API.cpp.dll", CallingConvention = System.Runtime.InteropServices.CallingConvention.Cdecl)]
        public static extern bool SendCommand(string script);

        public Form1()
        {
            InitializeComponent();
            cmdListTXT.Text = @"kill {plr}
float {plr}
nofloat {plr}
chat {plr} {text}
ff {plr}
noff {plr}
blockhead {plr}
nolimbs {plr}
noarms {plr}
nolegs {plr}
fire {plr}
nofire {plr}
sparkles {plr}
nosparkles {plr}
smoke {plr}
nosmoke {plr}
print {text}
warn {text}
hipheight {plr} {number}
btools {plr}
music {musicid}
skybox {decalid}
vectorteleport {xpos} {ypos} {zpos}";
        }

        private void exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void flatButton1_Click(object sender, EventArgs e)
        {
            LaunchExploit();
        }

        private void lLUAbtn_Click(object sender, EventArgs e)
        {
            SendLimitedLuaScript(srcCodeTXT.Text);
        }

        private void LUACbtn_Click(object sender, EventArgs e)
        {
            SendLuaCScript(srcCodeTXT.Text);
        }

        private void flatButton2_Click(object sender, EventArgs e)
        {
            SendCommand(cmdTXT.Text);
            cmdLS.Text = cmdLS.Text + @"
" + cmdTXT.Text;
        }

        private void flatTabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
